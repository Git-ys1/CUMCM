"""MathModel test package."""
